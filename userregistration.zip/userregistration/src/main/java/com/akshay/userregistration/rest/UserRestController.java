package com.akshay.userregistration.rest;

import com.akshay.userregistration.model.Response;
import com.akshay.userregistration.model.User;
import com.akshay.userregistration.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
public class UserRestController {

    @Autowired
    private UserRepository _userRepository;

    @PostMapping("/register")
    public ResponseEntity<Response> register(@Valid @RequestBody User user){
        boolean isUserExist = isUserNameExist(user.getUsername()).isPresent();

        if (isUserExist){
            return ResponseEntity.ok(new Response(false, "Username already exist!!"));
        }else {
            _userRepository.save(user);
            return ResponseEntity.ok(new Response(true, "User registered successfully"));
        }
    }

    @GetMapping("/search/{username}")
    public Response search(String username){
        Optional<User> existingUser = isUserNameExist(username);

        if (existingUser.isPresent()){
            return new Response(existingUser.isPresent(), "Username is already existing!!");
        }else {
            return new Response(existingUser.isPresent(), "Username doesn't exist!!");
        }
    }

    @GetMapping("/getAllUsers")
    public List<User> getAllUsers(){
        return _userRepository.findAll();
    }

    private Optional<User> isUserNameExist(String username){
        return _userRepository.findUserByUsername(username);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(
            MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }

}
