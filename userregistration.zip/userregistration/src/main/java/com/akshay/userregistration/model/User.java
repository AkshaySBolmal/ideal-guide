package com.akshay.userregistration.model;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name = "user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "Username is mandatory")
    @Size(min = 3, max = 20, message = "Username must be between 3 and 20 characters")
    @Column(name = "username")
    private String username;

    @NotBlank(message = "First Name is mandatory")
    @Size(min = 3, max = 20, message = "First name must be between 3 and 20 characters")
    @Column(name = "fname")
    private String fname;

    @NotBlank(message = "Last Name is mandatory")
    @Size(min = 3, max = 20, message = "Last name must be between 3 and 20 characters")
    @Column(name = "lname")
    private  String lname;

    @Email(message = "EMail is not a valid email")
    @NotBlank(message = "EMail is mandatory")
    @Column(name = "email")
    private String email;

    public User(Long id, String username, String fname, String lname, String email) {
        this.id = id;
        this.username = username;
        this.fname = fname;
        this.lname = lname;
        this.email = email;
    }

    public User(String username, String fname, String lname, String email) {
        this.username = username;
        this.fname = fname;
        this.lname = lname;
        this.email = email;
    }

    public User() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", fname='" + fname + '\'' +
                ", lname='" + lname + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
