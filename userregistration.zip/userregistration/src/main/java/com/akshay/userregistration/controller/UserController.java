package com.akshay.userregistration.controller;

import com.akshay.userregistration.model.User;
import com.akshay.userregistration.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/")
public class UserController {

    @Autowired
    private UserRepository _userRepository;

    @GetMapping("/")
    public String index(){
        return"/index";
    }

    @GetMapping("/users")
    public String users(){
        return "/users";
    }

}
